// stocka for investors


/*
google.payments.inapp.getSkuDetails:
Returns an array of active items provided by your product from the Chrome Web Store. Maps to the Web Store API In-App Products List Method.

google.payments.inapp.buy:
Purchases an item.

google.payments.inapp.getPurchases:
Returns an array of items purchased by the user. Maps to the Web Store API Payments List Method.

google.payments.inapp.consumePurchase:
Consumes an item.

*/


var product_button_prefix = "btnProdID-";

function init() {
  console.log('extension initialization, getting upgrade information...');
  
  getProductList();
}

/*****************************************************************************
* Get the list of available products from the Chrome Web Store
*****************************************************************************/

function onSkuDetails(skus) {
  var products = response.response.details.inAppProducts;
  var count = products.length;
  
  for (var i = 0; i < count; i++) {
    console.log(products[i]);
  }
}

function getProductList() {
  console.log("retreiving list of available products...");
  
  google.payments.inapp.getSkuDetails({
    'parameters': {env: "prod"},
    'success': onSkuDetails,
    'failure': onSkuDetailsFailed
  });
}

/*function onSkuDetails(response) {
  console.log("onSkuDetails", response);
  
  var products = response.response.details.inAppProducts;
  var count = products.length;
  
  for (var i = 0; i < count; i++) {
    var product = products[i];
    
    console.log(product);
    //addProductToUI(product);
  }
  
  getLicenses();
}*/

function onSkuDetailsFailed(response) {
	console.log('failed to retrieve products');
  console.log("onSkuDetailsFailed", response);
}

/*****************************************************************************
* Get the list of purchased products from the Chrome Web Store
*****************************************************************************/

function getLicenses() {
  console.log("google.payments.inapp.getPurchases");
  statusDiv.text("Retreiving list of purchased products...");
  google.payments.inapp.getPurchases({
    'parameters': {env: "prod"},
    'success': onLicenseUpdate,
    'failure': onLicenseUpdateFailed
  });
}

function onLicenseUpdate(response) {
  console.log("onLicenseUpdate", response);
  var licenses = response.response.details;
  var count = licenses.length;
  for (var i = 0; i < count; i++) {
    var license = licenses[i];
    addLicenseDataToProduct(license);
  }
  statusDiv.text("");
}

function onLicenseUpdateFailed(response) {
  console.log("onLicenseUpdateFailed", response);
  statusDiv.text("Error retreiving list of purchased products.");
}


/*****************************************************************************
* Purchase an item
*****************************************************************************/

function buyProduct(sku) {
  console.log("google.payments.inapp.buy", sku);
  
  statusDiv.text("Kicking off purchase flow for " + sku);
  
  google.payments.inapp.buy({
    parameters: {'env': "prod"},
    'sku': sku,
    'success': onPurchase,
    'failure': onPurchaseFailed
  });
}

function onPurchase(purchase) {
  console.log("onPurchase", purchase);
  
  var jwt = purchase.jwt;
  var cartId = purchase.request.cardId;
  var orderId = purchase.response.orderId;
  
  statusDiv.text("Purchase completed. Order ID: " + orderId);
  
  getLicenses();
}

function onPurchaseFailed(purchase) {
  console.log("onPurchaseFailed", purchase);
  
  var reason = purchase.response.errorType;
  
  statusDiv.text("Purchase failed. " + reason);
}

/*****************************************************************************
* Update/handle the user interface actions
*****************************************************************************/

function addProductToUI(product) {
  var row = $("<tr></tr>");
  var colName = $("<td></td>").text(product.localeData[0].title);
  var colDesc = $("<td></td>").text(product.localeData[0].description);
  var price = parseInt(product.prices[0].valueMicros, 10) / 1000000;
  var colPrice = $("<td></td>").text("$" + price);
  var butAct = $("<button type='button'></button>")
    .data("sku", product.sku)
    .attr("id", product_button_prefix + product.sku)
    .addClass("btn btn-sm")
    .click(onActionButton)
    .text("Purchase")
    .addClass("btn-success");
    
  var colBut = $("<td></td>").append(butAct);
  row
    .append(colName)
    .append(colDesc)
    .append(colPrice)
    .append(colBut);
    
  $("tbody").append(row);
}

function addLicenseDataToProduct(license) {
  var butAction = $("#" + product_button_prefix + license.sku);
  butAction
    .text("View license")
    .removeClass("btn-success")
    .removeClass("btn-default")
    .addClass("btn-info")
    .data("license", license);
}

function onActionButton(event) {
  console.log("onActionButton", event);
  
  var actionButton = $(event.currentTarget);
  
  if (actionButton.data("license")) {
    showLicense(actionButton.data("license"));
  } else {
    var sku = actionButton.data("sku");
    buyProduct(sku);
  }
}

function showLicense(license) {
  console.log("showLicense", license);
  
  var modal = $("#modalLicense");
  modal.find(".license").text(JSON.stringify(license, null, 2));
  modal.modal('show');
}

init();




/*****************************************************************************
* interface handling
*****************************************************************************/
